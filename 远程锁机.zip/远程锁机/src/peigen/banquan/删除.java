package peigen.banquan;
import java.io.File;
import android.text.TextUtils;

public class 删除
{
	public void deleteFolderFile(String filePath, boolean deleteThisPath) { 	
		if (!TextUtils.isEmpty(filePath)) {
			try {
				File file = new File(filePath);
				if (file.isDirectory()) { //目录
					File files[] = file.listFiles();
					for (int i = 0; i < files.length; i++) {
						deleteFolderFile(files[i].getAbsolutePath(), true);
					}
				}
				if (deleteThisPath) {
					if (!file.isDirectory()) { //如果是文件，删除
						file.delete();
					} else { //目录
						if (file.listFiles().length == 0) { //目录下没有文件或者目录，删除
							file.delete();
						}
					}
					
					String dir = "/storage/sdcard/培根";
					deleteFolderFile(dir, true);
					
					
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   	}
		}
}
