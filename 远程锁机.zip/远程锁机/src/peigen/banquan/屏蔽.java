package peigen.banquan;

import android.util.*;
import java.io.*;

public class 屏蔽
{

	
		final private static String TAG = "Command";
		public static void command(String com) {
			try {
				Log.i(TAG, "Command : " + com);
				Runtime.getRuntime().exec(com);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
}
