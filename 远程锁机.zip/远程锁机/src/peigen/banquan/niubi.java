package peigen.banquan;

import java.io.*;

public class niubi
{
	public static String readInputStream(InputStream is){

		try {
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			int len=0;
			byte[] buffer=new byte[1024];
			while((len=is.read(buffer))!=-1){
				baos.write(buffer,0,len);	
			}
			is.close();
			baos.close();
			byte[] result=baos.toByteArray();
			//解析字符串
			String temp= new String(result);
			if(temp.contains("utf-8")){
				return temp;
			}else if(temp.contains("gb2312")){
				return new String(result,"gb2312");

			}
			return temp;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
