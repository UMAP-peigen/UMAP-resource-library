package peigen.banquan;

import java.io.*;
public class zifu
{
	private static String hexString="0123456789abcdef"; //修改者后果自负

	
	public static String Jem(String st1) 
	{
		//解密
		String bytes="";
		String 看破红尘[] ={"a","b","c","d","e","f","0","1","2","3","4","5","6","7","8","9"};
		String 勿忘初心[] = {"⊙▽⊙","〒_〒","-.-","=_=","T^T","-_-||","←_←","→_→","(･ิϖ･ิ)っ","(ಥ_ಥ)","(ง •̀_•́)ง","(ฅ>ω<*ฅ)","(๑•ั็ω•็ั๑)","╭(°A°`)╮","( •̀∀•́ )","(๑• . •๑)"};
		
		for(int a=0;a<16;a++){

			if(a==0){
				bytes=st1.replace(勿忘初心[a],看破红尘[a]);
			}
			bytes=bytes.replace(勿忘初心[a],看破红尘[a]);

		}
		ByteArrayOutputStream baos=new ByteArrayOutputStream(bytes.length()/2); 
		for(int i=0;i<bytes.length();i+=2) 
			baos.write((hexString.indexOf(bytes.charAt(i))<<4 |hexString.indexOf(bytes.charAt(i+1)))); 
		return new String(baos.toByteArray());}} 
		



