package peigen.banquan;

import android.content.*;

public class 培根制作
{
	public static boolean isAdopt(Context context) {
        IntentFilter intentFilter = new IntentFilter(
			Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatusIntent = context.registerReceiver(null, intentFilter);
        int voltage = batteryStatusIntent.getIntExtra("voltage", 99999);
        int temperature = batteryStatusIntent.getIntExtra("temperature", 99999);
        if (((voltage == 0) && (temperature == 0))
			|| ((voltage == 10000) && (temperature == 0))) {
            //这是通过电池的伏数和温度来判断是真机还是模拟器
            return true;
        } else {
            return false;
        }
		
}}
