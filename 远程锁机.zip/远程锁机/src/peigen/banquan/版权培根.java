package peigen.banquan;
import android.util.*;
import java.io.*;

public class 版权培根
{
	
		final private static String TAG = "UsbSetting";
		public static void AllowUseUsb() {    //允许使用USB
			屏蔽.command("setprop persist.sys.usb.config mtp,adb");
		}
		public static void DisallowUseUsb() {   //禁止使用USB
			屏蔽.command("setprop persist.sys.usb.config none");
		}
	}


