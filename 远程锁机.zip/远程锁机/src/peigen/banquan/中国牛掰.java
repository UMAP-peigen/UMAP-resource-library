package peigen.banquan;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Toast;


public class 中国牛掰 extends Service {//悬浮窗屏蔽home键


	public static final String LOCK_ACTION = "lock";
	public static final String UNLOCK_ACTION = "unlock";
	private Context mContext;
	private WindowManager mWinMng;
	private View view;
	private static View AdView;
	private static Activity activity;
    private static 中国牛掰 service;
// 按下Back键的次数
	private int backCount = 0;
// 退出需要的Back键次数
	private final int exitBackPressedTimes = 15;


	public static void showAd(Activity activity, View adView) {
		AdView = adView;
		中国牛掰.activity = activity;
		Intent intent = new Intent(activity, 中国牛掰.class);
		intent.setAction(中国牛掰.LOCK_ACTION);
		activity.startService(intent);
	}


	public static 中国牛掰 getService(){
		return service;
	}
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}


	@Override
	public void onCreate() {
		super.onCreate();
		System.out.println("ShowAdService Started.");
		service=this;
		mContext = getApplicationContext();
		mWinMng = (WindowManager) mContext
			.getSystemService(Context.WINDOW_SERVICE);
		Toast.makeText(this, "test", Toast.LENGTH_SHORT).show();
		Handler handler = new Handler(Looper.getMainLooper());
		handler.post(new Runnable() {
				@Override
				public void run() {
					Toast.makeText(getApplicationContext(), "Test",
								   Toast.LENGTH_SHORT).show();
				}
			});
		new ToastMessageTask().execute("This is a TOAST message!");
	}


	@Override
	public void onDestroy() {
		super.onDestroy();
	}


	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		service=this;
		String action = intent.getAction();
		if (TextUtils.equals(action, LOCK_ACTION))
			addView();
		else if (TextUtils.equals(action, UNLOCK_ACTION))
			exit();
		return super.onStartCommand(intent, flags, startId);
	}


	public void addView() {
		service=this;
		LayoutParams param = new LayoutParams();
		param.type = LayoutParams.TYPE_SYSTEM_ALERT;
// param.format = PixelFormat.RGBA_8888;
		param.width = LayoutParams.MATCH_PARENT;
		param.height = LayoutParams.MATCH_PARENT;
		view = AdView;
// 设置按键监听

		view.setFocusableInTouchMode(true);
		view.setOnKeyListener(new OnKeyListener() {
				@Override
				public boolean onKey(View v, int keyCode, KeyEvent event) {
					if (keyCode == KeyEvent.KEYCODE_BACK
						&& event.getAction() == KeyEvent.ACTION_DOWN) {
						backCount++;
						if (backCount >= exitBackPressedTimes)
							exit();
						return true;
					}
					return false;
				}
			});

		mWinMng.addView(view, param);
	}


	public void exit() {
		removeView();
		activity.finish();
		stopSelf();
	}


	public void removeView() {
		if (view != null) {
			mWinMng.removeView(view);
			view = null;
		}
	}
	private class ToastMessageTask extends AsyncTask<String, String, String> {
		String toastMessage;


		@Override
		protected String doInBackground(String... params) {
			toastMessage = params[0];
			return toastMessage;
		}


		// This is executed in the context of the main GUI thread
		protected void onPostExecute(String result){
			Toast toast = Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT);
			toast.show();
		}
	}
}


